import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'state.dart';
import 'theme.dart';
import 'screens/shell.dart';

void main() => runApp(ChangeNotifierProvider(
      create: (_) => AppState(),
      child: const AnaqaApp(),
    ));

class AnaqaApp extends StatelessWidget {
  const AnaqaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'أناقة',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: const Shell(),
      );
}
