import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'data.dart';
import 'state.dart';
import 'theme.dart';
import 'screens/product_detail.dart';

String money(int v) {
  final s = v.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return '$s د.ع';
}

/// Primary (filled emerald) or ghost (outlined) sharp button.
class SharpButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final bool ghost;
  final IconData? icon;
  const SharpButton(this.label, {super.key, this.onTap, this.ghost = false, this.icon});
  @override
  Widget build(BuildContext context) {
    final fg = ghost ? C.emerald : C.bg;
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: Material(
        color: ghost ? Colors.transparent : C.emerald,
        shape: Border.fromBorderSide(BorderSide(color: C.emerald, width: ghost ? 1 : 0)),
        child: InkWell(
          onTap: onTap,
          child: Center(
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              if (icon != null) ...[Icon(icon, color: fg, size: 18), const SizedBox(width: 8)],
              Text(label, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 15)),
            ]),
          ),
        ),
      ),
    );
  }
}

class Tag extends StatelessWidget {
  final String text;
  final Color color;
  const Tag(this.text, {super.key, this.color = C.emerald});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        color: color,
        child: Text(text,
            style: const TextStyle(color: C.bg, fontSize: 11, fontWeight: FontWeight.w800)),
      );
}

class Box extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color? borderColor;
  const Box({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.borderColor});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        padding: padding,
        decoration: BoxDecoration(
            color: C.surface, border: Border.all(color: borderColor ?? C.border)),
        child: child,
      );
}

class SectionLabel extends StatelessWidget {
  final String text;
  const SectionLabel(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10, top: 6),
        child: Text(text, style: heading(17)),
      );
}

class ProductCard extends StatelessWidget {
  final Product p;
  const ProductCard(this.p, {super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final fav = s.favs.contains(p.id);
    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetail(p))),
      child: Container(
        decoration: BoxDecoration(color: C.surface, border: Border.all(color: C.border)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          AspectRatio(
            aspectRatio: 1.0,
            child: Stack(fit: StackFit.expand, children: [
              Image.asset(p.image, fit: BoxFit.cover, alignment: Alignment.topCenter),
              Positioned(top: 8, left: 8,
                  child: GestureDetector(
                    onTap: () => s.toggleFav(p.id),
                    child: Container(
                      width: 34, height: 34, color: C.bg.withOpacity(.7),
                      child: Icon(fav ? Icons.favorite : Icons.favorite_border,
                          size: 18, color: fav ? C.emerald : Colors.white),
                    ),
                  )),
              if (p.badge != null) Positioned(top: 8, right: 8, child: Tag(p.badge!)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(p.category,
                    style: const TextStyle(color: C.muted, fontSize: 11), maxLines: 1,
                    overflow: TextOverflow.ellipsis)),
                const Icon(Icons.star, size: 12, color: C.bronze),
                Text(' ${p.rating}', style: numeric(11, color: Colors.white)),
              ]),
              const SizedBox(height: 4),
              Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13, height: 1.35)),
              const SizedBox(height: 8),
              Text(money(p.price), style: numeric(16)),
              if (p.oldPrice != null)
                Text(money(p.oldPrice!),
                    style: numeric(11, color: C.dim, w: FontWeight.w400)
                        .copyWith(decoration: TextDecoration.lineThrough)),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity, height: 36,
                child: OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                      shape: const RoundedRectangleBorder(),
                      side: const BorderSide(color: C.border2), foregroundColor: Colors.white),
                  onPressed: () {
                    s.add(p);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        duration: Duration(seconds: 1), content: Text('تمت الإضافة إلى السلة')));
                  },
                  icon: const Icon(Icons.add_shopping_cart, size: 16),
                  label: const Text('إضافة للسلة', style: TextStyle(fontSize: 12)),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
