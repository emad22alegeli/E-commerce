import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat.dart';

class SuccessScreen extends StatelessWidget {
  const SuccessScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    const steps = [
      ('استلام الطلب وتأكيد السداد', true),
      ('جاري التجهيز والتغليف الملكي', true),
      ('مع مندوب أناقة الخاص', false),
      ('التسليم عند باب الجناح الملكي', false),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('ANAQA'), automaticallyImplyLeading: false),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const SizedBox(height: 10),
        const Icon(Icons.check_circle_outline, size: 72, color: C.emerald),
        const SizedBox(height: 12),
        Center(child: Text('تهانينا! تم تأكيد طلبك بنجاح', style: heading(22))),
        const SizedBox(height: 8),
        Center(child: Text('رقم الطلب: ${s.lastOrderId ?? ''}', style: numeric(14, color: C.muted))),
        const SizedBox(height: 4),
        Center(child: Text(s.gov.eta, style: const TextStyle(color: C.muted))),
        const SectionLabel('تتبع الشحنة'),
        Box(child: Column(children: [
          for (final st in steps)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(children: [
                Icon(st.$2 ? Icons.check_box : Icons.check_box_outline_blank,
                    color: st.$2 ? C.emerald : C.dim),
                const SizedBox(width: 12),
                Text(st.$1, style: TextStyle(color: st.$2 ? Colors.white : C.muted)),
              ]),
            ),
        ])),
        const SizedBox(height: 16),
        SharpButton('الدردشة مع الكونسيرج', ghost: true, icon: Icons.support_agent,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen()))),
        const SizedBox(height: 10),
        SharpButton('العودة للتسوق', onTap: () {
          s.setTab(0);
          Navigator.popUntil(context, (r) => r.isFirst);
        }),
      ]),
    );
  }
}
