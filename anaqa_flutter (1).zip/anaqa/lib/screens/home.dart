import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'governorate.dart';
import 'chat.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final cats = ['الكل', ...{for (final p in products) p.category}];
    final list = s.filtered;
    return SafeArea(
      child: CustomScrollView(slivers: [
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                IconButton(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())),
                  icon: const Icon(Icons.support_agent, color: C.emerald),
                ),
                const Spacer(),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('ANAQA | أناقة', style: heading(18).copyWith(color: C.emerald)),
                  GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GovernorateScreen())),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Text('التوصيل إلى ${s.gov.name}', style: const TextStyle(color: C.muted, fontSize: 12)),
                      const Icon(Icons.keyboard_arrow_down, size: 16, color: C.muted),
                    ]),
                  ),
                ]),
              ]),
              const SizedBox(height: 14),
              const Text('مجموعة الخريف الفاخرة', style: TextStyle(color: C.emerald, fontSize: 12)),
              Text('عبايات وتصاميم الموسم', style: heading(26)),
              const SizedBox(height: 14),
              TextField(
                onChanged: s.setQuery,
                decoration: const InputDecoration(
                    hintText: 'ابحثي بالاسم، القماش، القصة...', prefixIcon: Icon(Icons.search, color: C.muted)),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 38,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: cats.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (_, i) {
                    final sel = s.category == cats[i];
                    return GestureDetector(
                      onTap: () => s.setCategory(cats[i]),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: sel ? C.emerald : C.panel,
                            border: Border.all(color: sel ? C.emerald : C.border2)),
                        child: Text(cats[i],
                            style: TextStyle(color: sel ? C.bg : Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                      ),
                    );
                  },
                ),
              ),
            ]),
          ),
        ),
        if (list.isEmpty)
          const SliverFillRemaining(hasScrollBody: false, child: Center(child: Text('لا توجد نتائج', style: TextStyle(color: C.muted))))
        else
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            sliver: SliverGrid.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.52),
              itemCount: list.length,
              itemBuilder: (_, i) => ProductCard(list[i]),
            ),
          ),
      ]),
    );
  }
}
