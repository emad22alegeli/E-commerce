import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'chat.dart';
import 'governorate.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    void go(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));
    Widget tile(IconData i, String t, VoidCallback f) => GestureDetector(
          onTap: f,
          child: Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: C.surface, border: Border.all(color: C.border)),
            child: Row(children: [
              Icon(i, color: C.emerald), const SizedBox(width: 12), Text(t),
              const Spacer(), const Icon(Icons.chevron_left, color: C.muted),
            ]),
          ),
        );
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
              color: C.panel, border: Border.all(color: C.bronze.withOpacity(.6))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Tag('عضوية VIP', color: C.bronze),
            const SizedBox(height: 12),
            Text('صاحبة السمو / نورة', style: heading(20)),
            const SizedBox(height: 6),
            Text('وجهة التوصيل: ${s.gov.name}', style: const TextStyle(color: C.muted)),
          ]),
        ),
        const SizedBox(height: 16),
        tile(Icons.location_on_outlined, 'تغيير محافظة التوصيل', () => go(const GovernorateScreen())),
        tile(Icons.support_agent, 'الكونسيرج المباشر', () => go(const ChatScreen())),
        tile(Icons.favorite_border, 'المفضلة', () => s.setTab(2)),
        tile(Icons.shopping_bag_outlined, 'السلة', () => s.setTab(3)),
      ]),
    );
  }
}
