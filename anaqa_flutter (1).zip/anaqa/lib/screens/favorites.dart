import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final list = products.where((p) => s.favs.contains(p.id)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: list.isEmpty
          ? const Center(child: Text('لم تضيفي أي قطعة للمفضلة بعد', style: TextStyle(color: C.muted)))
          : GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.52),
              itemCount: list.length,
              itemBuilder: (_, i) => ProductCard(list[i]),
            ),
    );
  }
}
