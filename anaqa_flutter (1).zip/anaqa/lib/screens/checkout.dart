import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'cart.dart' show summaryRow;
import 'governorate.dart';
import 'success.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة الطلب')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const SectionLabel('عنوان التوصيل'),
        GestureDetector(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GovernorateScreen())),
          child: Box(child: Row(children: [
            const Icon(Icons.location_on_outlined, color: C.emerald),
            const SizedBox(width: 10),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.gov.name, style: const TextStyle(fontWeight: FontWeight.w800)),
              Text(s.gov.eta, style: const TextStyle(color: C.muted, fontSize: 12)),
            ])),
            const Icon(Icons.chevron_left, color: C.muted),
          ])),
        ),
        const SizedBox(height: 10),
        TextField(
          onChanged: s.setAddress,
          maxLines: 2,
          decoration: const InputDecoration(hintText: 'الحي، الشارع، أقرب نقطة دالة'),
        ),
        const SectionLabel('طريقة الدفع'),
        for (final e in paymentMethods.entries)
          GestureDetector(
            onTap: () => s.setPayment(e.key),
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: C.surface,
                  border: Border.all(color: s.payment == e.key ? C.emerald : C.border)),
              child: Row(children: [
                Icon(s.payment == e.key ? Icons.radio_button_checked : Icons.radio_button_off,
                    color: s.payment == e.key ? C.emerald : C.muted),
                const SizedBox(width: 12),
                Text(e.value),
              ]),
            ),
          ),
        const SectionLabel('ملخص الطلب'),
        Box(child: Column(children: [
          for (final c in s.cart) summaryRow('${c.p.category} × ${c.qty}', money(c.p.price * c.qty)),
          const Divider(color: C.border),
          if (s.discount > 0) summaryRow('الخصم', '- ${money(s.discount)}', color: C.emerald),
          summaryRow('الشحن', s.shipping == 0 ? 'مجاني' : money(s.shipping)),
          summaryRow('الإجمالي', money(s.total), big: true),
        ])),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SharpButton('تأكيد الطلب', icon: Icons.lock_outline, onTap: s.cart.isEmpty ? null : () {
            if (s.address.trim().isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الرجاء إدخال العنوان')));
              return;
            }
            s.placeOrder();
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const SuccessScreen()));
          }),
        ),
      ),
    );
  }
}
