import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';
import 'home.dart';
import 'categories.dart';
import 'favorites.dart';
import 'cart.dart';
import 'profile.dart';

class Shell extends StatelessWidget {
  const Shell({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    const pages = [HomeScreen(), CategoriesScreen(), FavoritesScreen(), CartScreen(), ProfileScreen()];
    const items = [
      (Icons.home_outlined, 'الرئيسية'),
      (Icons.grid_view_outlined, 'التصنيفات'),
      (Icons.favorite_border, 'المفضلة'),
      (Icons.shopping_bag_outlined, 'السلة'),
      (Icons.person_outline, 'حسابي'),
    ];
    return Scaffold(
      body: IndexedStack(index: s.tab, children: pages),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: C.surface, border: Border(top: BorderSide(color: C.border))),
        child: SafeArea(
          child: Row(children: [
            for (var i = 0; i < items.length; i++)
              Expanded(
                child: InkWell(
                  onTap: () => s.setTab(i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                        border: Border(top: BorderSide(
                            color: s.tab == i ? C.emerald : Colors.transparent, width: 2))),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Badge(
                        isLabelVisible: i == 3 && s.cartCount > 0,
                        label: Text('${s.cartCount}'),
                        backgroundColor: C.emerald, textColor: C.bg,
                        child: Icon(items[i].$1, color: s.tab == i ? C.emerald : C.muted),
                      ),
                      const SizedBox(height: 3),
                      Text(items[i].$2,
                          style: TextStyle(fontSize: 11, color: s.tab == i ? C.emerald : C.muted)),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
