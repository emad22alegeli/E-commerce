import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final ctrl = TextEditingController();
  @override
  void dispose() { ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('كونسيرج أناقة')),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: s.chat.length,
            itemBuilder: (_, i) {
              final m = s.chat[i];
              return Align(
                alignment: m.mine ? Alignment.centerRight : Alignment.centerLeft,
                child: Container(
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .75),
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: m.mine ? C.emerald : C.panel,
                      border: Border.all(color: m.mine ? C.emerald : C.border2)),
                  child: Text(m.text, style: TextStyle(color: m.mine ? C.bg : Colors.white, height: 1.5)),
                ),
              );
            },
          ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Expanded(child: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'اكتبي رسالتك...'))),
              const SizedBox(width: 8),
              Container(
                color: C.emerald, width: 50, height: 50,
                child: IconButton(
                  icon: const Icon(Icons.send, color: C.bg),
                  onPressed: () { s.sendChat(ctrl.text); ctrl.clear(); },
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}
