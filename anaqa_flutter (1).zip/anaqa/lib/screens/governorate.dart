import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class GovernorateScreen extends StatefulWidget {
  const GovernorateScreen({super.key});
  @override
  State<GovernorateScreen> createState() => _GovernorateScreenState();
}

class _GovernorateScreenState extends State<GovernorateScreen> {
  String q = '';
  late Governorate sel = context.read<AppState>().gov;
  @override
  Widget build(BuildContext context) {
    final list = governorates.where((g) => g.name.contains(q) || g.sub.contains(q)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('تحديد المحافظة')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('تحديد محافظة ومدينة التوصيل (العراق)', style: heading(20)),
        const SizedBox(height: 6),
        const Text('اختاري محافظتك لعرض مواعيد الشحن المتاحة لكافة المحافظات العراقية.',
            style: TextStyle(color: C.muted, height: 1.6)),
        const SizedBox(height: 14),
        TextField(
          onChanged: (v) => setState(() => q = v),
          decoration: const InputDecoration(hintText: 'ابحثي عن محافظة', prefixIcon: Icon(Icons.search, color: C.muted)),
        ),
        const SizedBox(height: 12),
        for (final g in list)
          GestureDetector(
            onTap: () => setState(() => sel = g),
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                  color: C.surface,
                  border: Border.all(color: sel == g ? C.emerald : C.border)),
              child: Row(children: [
                Icon(Icons.location_city, color: sel == g ? C.emerald : C.muted),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(g.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text('${g.sub} • ${g.eta}', style: const TextStyle(color: C.muted, fontSize: 12)),
                ])),
                if (sel == g) const Icon(Icons.check_circle, color: C.emerald),
              ]),
            ),
          ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SharpButton('تأكيد المحافظة والمتابعة (${sel.name})', onTap: () {
            context.read<AppState>().setGov(sel);
            Navigator.pop(context);
          }),
        ),
      ),
    );
  }
}
