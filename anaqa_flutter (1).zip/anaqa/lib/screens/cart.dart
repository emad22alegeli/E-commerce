import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'checkout.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});
  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final ctrl = TextEditingController();
  @override
  void dispose() { ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('السلة')),
      body: s.cart.isEmpty
          ? const Center(child: Text('سلتك فارغة', style: TextStyle(color: C.muted)))
          : ListView(padding: const EdgeInsets.all(16), children: [
              Box(
                borderColor: C.emerald.withOpacity(.4),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                      s.shipping == 0
                          ? 'مبروك! حصلتِ على شحن VIP مجاني 🚀'
                          : 'أضيفي ${money(AppState.freeShippingFrom - s.subtotal)} للحصول على شحن مجاني',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                      value: s.freeShippingProgress, minHeight: 4,
                      backgroundColor: C.border, color: C.emerald),
                ]),
              ),
              const SizedBox(height: 14),
              for (final c in s.cart)
                Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(color: C.surface, border: Border.all(color: C.border)),
                  child: Row(children: [
                    SizedBox(width: 100, height: 120,
                        child: Image.asset(c.p.image, fit: BoxFit.cover, alignment: Alignment.topCenter)),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(c.p.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text('المقاس: ${c.size}', style: const TextStyle(color: C.muted, fontSize: 12)),
                          const SizedBox(height: 8),
                          Text(money(c.p.price), style: numeric(15)),
                          const SizedBox(height: 6),
                          Row(children: [
                            _qtyBtn(Icons.remove, () => s.setQty(c, c.qty - 1)),
                            SizedBox(width: 36, child: Center(child: Text('${c.qty}', style: numeric(15, color: Colors.white)))),
                            _qtyBtn(Icons.add, () => s.setQty(c, c.qty + 1)),
                            const Spacer(),
                            IconButton(
                                onPressed: () => s.setQty(c, 0),
                                icon: const Icon(Icons.delete_outline, color: C.red, size: 20)),
                          ]),
                        ]),
                      ),
                    ),
                  ]),
                ),
              const SectionLabel('رمز الخصم'),
              Row(children: [
                Expanded(child: TextField(controller: ctrl, decoration: const InputDecoration(hintText: 'ANAQA50'))),
                const SizedBox(width: 8),
                SizedBox(
                  height: 50,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        shape: const RoundedRectangleBorder(), side: const BorderSide(color: C.emerald)),
                    onPressed: () {
                      final ok = s.applyCoupon(ctrl.text);
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(ok ? 'تم تطبيق الخصم 10%' : 'رمز غير صالح')));
                    },
                    child: const Text('تطبيق', style: TextStyle(color: C.emerald)),
                  ),
                ),
              ]),
              const SizedBox(height: 16),
              const SectionLabel('ملخص الحساب'),
              Box(child: Column(children: [
                summaryRow('المجموع الفرعي', money(s.subtotal)),
                if (s.discount > 0) summaryRow('خصم ANAQA50', '- ${money(s.discount)}', color: C.emerald),
                summaryRow('الشحن', s.shipping == 0 ? 'مجاني' : money(s.shipping)),
                const Divider(color: C.border),
                summaryRow('الإجمالي', money(s.total), big: true),
              ])),
              const SizedBox(height: 16),
              SharpButton('متابعة إتمام الطلب', onTap: () =>
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const CheckoutScreen()))),
            ]),
    );
  }

  Widget _qtyBtn(IconData i, VoidCallback f) => InkWell(
        onTap: f,
        child: Container(
            width: 30, height: 30,
            decoration: BoxDecoration(border: Border.all(color: C.border2)),
            child: Icon(i, size: 16)),
      );
}

Widget summaryRow(String a, String b, {Color color = Colors.white, bool big = false}) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(a, style: TextStyle(color: big ? Colors.white : C.muted, fontWeight: big ? FontWeight.w800 : FontWeight.w400)),
        Text(b, style: numeric(big ? 20 : 14, color: big ? C.emerald : color)),
      ]),
    );
