import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class ProductDetail extends StatefulWidget {
  final Product p;
  const ProductDetail(this.p, {super.key});
  @override
  State<ProductDetail> createState() => _ProductDetailState();
}

class _ProductDetailState extends State<ProductDetail> {
  late int size = widget.p.sizes.first;
  @override
  Widget build(BuildContext context) {
    final p = widget.p;
    final s = context.watch<AppState>();
    final fav = s.favs.contains(p.id);
    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل القطعة'),
        actions: [
          IconButton(
            onPressed: () => s.toggleFav(p.id),
            icon: Icon(fav ? Icons.favorite : Icons.favorite_border, color: C.emerald),
          ),
        ],
      ),
      body: ListView(children: [
        AspectRatio(aspectRatio: 1, child: Image.asset(p.image, fit: BoxFit.cover, alignment: Alignment.topCenter)),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              if (p.badge != null) Tag(p.badge!),
              const Spacer(),
              const Icon(Icons.star, size: 14, color: C.bronze),
              Text(' ${p.rating} (${p.reviews})', style: numeric(13, color: Colors.white)),
            ]),
            const SizedBox(height: 10),
            Text(p.category, style: const TextStyle(color: C.muted, fontSize: 12)),
            Text(p.name, style: heading(22)),
            const SizedBox(height: 12),
            Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text(money(p.price), style: numeric(24)),
              const SizedBox(width: 10),
              if (p.oldPrice != null)
                Text(money(p.oldPrice!),
                    style: numeric(13, color: C.dim, w: FontWeight.w400)
                        .copyWith(decoration: TextDecoration.lineThrough)),
            ]),
            const SizedBox(height: 6),
            Text(p.payNote, style: const TextStyle(color: C.bronze, fontSize: 12)),
            const SizedBox(height: 18),
            const SectionLabel('المقاس'),
            Wrap(spacing: 8, children: [
              for (final z in p.sizes)
                GestureDetector(
                  onTap: () => setState(() => size = z),
                  child: Container(
                    width: 56, height: 44, alignment: Alignment.center,
                    decoration: BoxDecoration(
                        color: size == z ? C.emerald : C.panel,
                        border: Border.all(color: size == z ? C.emerald : C.border2)),
                    child: Text('$z',
                        style: numeric(15, color: size == z ? C.bg : Colors.white)),
                  ),
                ),
            ]),
            const SizedBox(height: 18),
            const SectionLabel('الوصف'),
            Text(p.description, style: const TextStyle(color: C.muted, height: 1.7)),
          ]),
        ),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: SharpButton('إضافة للسلة', icon: Icons.shopping_bag_outlined, onTap: () {
            s.add(p, size);
            s.setTab(3);
            Navigator.popUntil(context, (r) => r.isFirst);
          }),
        ),
      ),
    );
  }
}
