import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../state.dart';
import '../theme.dart';

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    final cats = {for (final p in products) p.category: p.image};
    return Scaffold(
      appBar: AppBar(title: const Text('التصنيفات')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        for (final e in cats.entries)
          GestureDetector(
            onTap: () => s.setCategory(e.key),
            child: Container(
              height: 120,
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                  border: Border.all(color: C.border),
                  image: DecorationImage(
                      image: AssetImage(e.value), fit: BoxFit.cover, alignment: Alignment.topCenter,
                      colorFilter: ColorFilter.mode(C.bg.withOpacity(.55), BlendMode.darken))),
              alignment: Alignment.centerRight,
              padding: const EdgeInsets.all(16),
              child: Text(e.key, style: heading(20)),
            ),
          ),
      ]),
    );
  }
}
