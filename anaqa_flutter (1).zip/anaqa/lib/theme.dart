import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Obsidian Emerald Couture - colors from DESIGN.md
class C {
  static const bg = Color(0xFF05080A);
  static const surface = Color(0xFF0A0F17);
  static const panel = Color(0xFF0F172A);
  static const border = Color(0xFF1E293B);
  static const border2 = Color(0xFF334155);
  static const emerald = Color(0xFF10B981);
  static const bronze = Color(0xFFD97706);
  static const muted = Color(0xFF94A3B8);
  static const dim = Color(0xFF475569);
  static const red = Color(0xFFEF4444);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  final text = GoogleFonts.cairoTextTheme(base.textTheme)
      .apply(bodyColor: Colors.white, displayColor: Colors.white);
  const sharp = RoundedRectangleBorder(borderRadius: BorderRadius.zero);
  OutlineInputBorder ob(Color c) => OutlineInputBorder(
      borderRadius: BorderRadius.zero, borderSide: BorderSide(color: c));
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
        primary: C.emerald, onPrimary: C.bg, surface: C.surface),
    textTheme: text,
    cardTheme: const CardTheme(shape: sharp, color: C.surface, margin: EdgeInsets.zero),
    dialogTheme: const DialogTheme(shape: sharp),
    chipTheme: const ChipThemeData(shape: sharp),
    appBarTheme: AppBarTheme(
      backgroundColor: C.bg,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: true,
      titleTextStyle: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.w700),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.surface,
      hintStyle: const TextStyle(color: C.muted),
      border: ob(C.border),
      enabledBorder: ob(C.border),
      focusedBorder: ob(C.emerald),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
    ),
  );
}

TextStyle heading(double size) => GoogleFonts.cairo(
    fontSize: size, fontWeight: FontWeight.w800, color: Colors.white, height: 1.25);
TextStyle numeric(double size, {Color color = C.emerald, FontWeight w = FontWeight.w700}) =>
    GoogleFonts.spaceGrotesk(fontSize: size, fontWeight: w, color: color);
