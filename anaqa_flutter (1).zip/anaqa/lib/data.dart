class Product {
  final String id, name, category, image, description, payNote;
  final int price;
  final int? oldPrice;
  final double rating;
  final int reviews;
  final String? badge;
  final List<int> sizes;
  const Product({
    required this.id,
    required this.name,
    required this.category,
    required this.image,
    required this.description,
    required this.payNote,
    required this.price,
    this.oldPrice,
    required this.rating,
    required this.reviews,
    this.badge,
    required this.sizes,
  });
}

class Governorate {
  final String name, sub, eta;
  const Governorate(this.name, this.sub, this.eta);
}

const products = <Product>[
  Product(
    id: 'a1',
    name: 'عباية كريب ليزر بقصة السيابية وطرحة مجانية',
    category: 'كريب ملكي أسود',
    image: 'assets/images/abaya1.jpg',
    description: 'كريب ملكي فاخر بقصة ليزر دقيقة مع طرحة مجانية. خياطة يدوية وتشطيب بخيوط زمردية خفيفة.',
    payNote: 'الدفع بالاستلام أو بأقساط زين كاش',
    price: 85000,
    oldPrice: 115000,
    rating: 4.9,
    reviews: 184,
    badge: 'خصم 25%',
    sizes: [52, 54, 56, 58],
  ),
  Product(
    id: 'a2',
    name: 'عباية بشت مطرزة بخيوط الحرير الأسود الملكي',
    category: 'بشت كلاسيكي',
    image: 'assets/images/abaya2.jpg',
    description: 'بشت كلاسيكي مطرز بخيوط الحرير الأسود بنقوش هندسية، إصدار حصري بكمية محدودة.',
    payNote: 'تقسيط ميسر عبر بطاقة كي كارد أو زين كاش',
    price: 125000,
    oldPrice: 160000,
    rating: 5.0,
    reviews: 92,
    badge: 'إصدار حصري',
    sizes: [54, 56, 58, 60],
  ),
  Product(
    id: 'a3',
    name: 'عباية رسمية للعمل بقصة كوت وياقة أنيقة مع طرحة متناسقة',
    category: 'كريب واقف مقاوم للتجعد',
    image: 'assets/images/abaya3.jpg',
    description: 'قصة كوت منظمة مناسبة للدوام الرسمي، قماش مقاوم للتجعد وطرحة متناسقة.',
    payNote: 'دفع إلكتروني عبر FIB عند الاستلام',
    price: 89000,
    oldPrice: 110000,
    rating: 4.9,
    reviews: 312,
    badge: 'طرحة مجانية',
    sizes: [52, 54, 56, 58, 60],
  ),
  Product(
    id: 'a4',
    name: 'عباية صيفية بأكمام مقلوبة وقماش تنفس خفيف',
    category: 'كتان معالج',
    image: 'assets/images/abaya4.jpg',
    description: 'كتان معالج بلون الجرافيت مع أكمام مقلوبة وخياطة زمردية رفيعة، خفيفة للصيف.',
    payNote: 'الدفع عند الاستلام متاح لجميع المحافظات',
    price: 68000,
    oldPrice: 85000,
    rating: 4.8,
    reviews: 67,
    badge: 'كتان صيفي بارد',
    sizes: [52, 54, 56, 58],
  ),
];

const governorates = <Governorate>[
  Governorate('بغداد', 'العاصمة', 'توصيل فوري ٣ ساعات'),
  Governorate('البصرة', 'الفيحاء', 'توصيل خلال ٢٤ ساعة'),
  Governorate('أربيل', 'إقليم كردستان', 'توصيل ٢٤ - ٤٨ ساعة'),
  Governorate('النجف الأشرف', 'الفرات الأوسط', 'توصيل خلال ٢٤ ساعة'),
  Governorate('كربلاء المقدسة', 'الفرات الأوسط', 'توصيل خلال ٢٤ ساعة'),
  Governorate('الموصل', 'نينوى', 'توصيل ٢٤ - ٤٨ ساعة'),
  Governorate('السليمانية', 'إقليم كردستان', 'توصيل ٤٨ ساعة'),
  Governorate('الحلة', 'بابل', 'توصيل خلال ٢٤ ساعة'),
];

const paymentMethods = <String, String>{
  'cod': 'الدفع عند الاستلام',
  'zain': 'زين كاش',
  'fib': 'FIB - المصرف الأول',
  'card': 'بطاقة كي كارد',
};
