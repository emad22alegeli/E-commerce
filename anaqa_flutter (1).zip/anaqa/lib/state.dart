import 'package:flutter/foundation.dart';
import 'data.dart';

class CartItem {
  final Product p;
  int size;
  int qty;
  CartItem(this.p, this.size, [this.qty = 1]);
}

class ChatMsg {
  final String text;
  final bool mine;
  ChatMsg(this.text, this.mine);
}

class AppState extends ChangeNotifier {
  static const freeShippingFrom = 150000;
  static const shippingFee = 5000;

  int tab = 0;
  String category = 'الكل';
  String query = '';
  Governorate gov = governorates.first;
  String address = '';
  String payment = 'cod';
  String? coupon;
  String? lastOrderId;
  final cart = <CartItem>[];
  final favs = <String>{};
  final chat = <ChatMsg>[
    ChatMsg('أهلاً بكِ في أناقة. أنا الكونسيرج الخاص بكِ، كيف أساعدك اليوم؟', false),
  ];

  void setTab(int i) { tab = i; notifyListeners(); }
  void setCategory(String c) { category = c; tab = 0; notifyListeners(); }
  void setQuery(String q) { query = q; notifyListeners(); }
  void setGov(Governorate g) { gov = g; notifyListeners(); }
  void setAddress(String a) { address = a; }
  void setPayment(String p) { payment = p; notifyListeners(); }

  List<Product> get filtered => products.where((p) {
        final okCat = category == 'الكل' || p.category == category;
        final okQ = query.isEmpty || p.name.contains(query) || p.category.contains(query);
        return okCat && okQ;
      }).toList();

  void toggleFav(String id) {
    favs.contains(id) ? favs.remove(id) : favs.add(id);
    notifyListeners();
  }

  void add(Product p, [int? size]) {
    final s = size ?? p.sizes.first;
    final i = cart.indexWhere((c) => c.p.id == p.id && c.size == s);
    if (i >= 0) { cart[i].qty++; } else { cart.add(CartItem(p, s)); }
    notifyListeners();
  }

  void setQty(CartItem c, int q) {
    if (q <= 0) { cart.remove(c); } else { c.qty = q; }
    notifyListeners();
  }

  bool applyCoupon(String code) {
    if (code.trim().toUpperCase() == 'ANAQA50') {
      coupon = 'ANAQA50';
      notifyListeners();
      return true;
    }
    return false;
  }

  int get cartCount => cart.fold(0, (a, c) => a + c.qty);
  int get subtotal => cart.fold(0, (a, c) => a + c.p.price * c.qty);
  int get discount => coupon == null ? 0 : (subtotal * 0.10).round();
  int get shipping => cart.isEmpty || subtotal >= freeShippingFrom ? 0 : shippingFee;
  int get total => subtotal - discount + shipping;
  double get freeShippingProgress => (subtotal / freeShippingFrom).clamp(0.0, 1.0);

  String placeOrder() {
    lastOrderId = 'ANQ-${DateTime.now().millisecondsSinceEpoch % 100000000}';
    cart.clear();
    coupon = null;
    notifyListeners();
    return lastOrderId!;
  }

  void sendChat(String text) {
    if (text.trim().isEmpty) return;
    chat.add(ChatMsg(text.trim(), true));
    notifyListeners();
    Future.delayed(const Duration(milliseconds: 900), () {
      chat.add(ChatMsg('تم استلام رسالتك، سيتواصل معك أحد مستشارينا خلال لحظات.', false));
      notifyListeners();
    });
  }
}
