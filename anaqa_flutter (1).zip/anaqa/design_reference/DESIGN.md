---
name: Obsidian Emerald Couture
colors:
  surface: '#0f131b'
  surface-dim: '#0f131b'
  surface-bright: '#353941'
  surface-container-lowest: '#0a0e15'
  surface-container-low: '#181c23'
  surface-container: '#1c2027'
  surface-container-high: '#262a32'
  surface-container-highest: '#31353d'
  on-surface: '#dfe2ed'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2ed'
  inverse-on-surface: '#2d3038'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#bec6e0'
  on-secondary: '#283044'
  secondary-container: '#3f465c'
  on-secondary-container: '#adb4ce'
  tertiary: '#ffb77d'
  on-tertiary: '#4d2600'
  tertiary-container: '#f08921'
  on-tertiary-container: '#5a2e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#dae2fd'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3f465c'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#0f131b'
  on-background: '#dfe2ed'
  surface-variant: '#31353d'
typography:
  display-hero:
    fontFamily: Syne
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Syne
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Syne
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Syne
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.15em
  label-numeric:
    fontFamily: Space Grotesk
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.02em
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
---

## Brand & Style
The design system establishes an avant-garde GCC boutique visual narrative tailored for high-end digital couture. It rejects generic luxury tropes in favor of structural intensity, high architectural precision, and an unapologetic nocturnal atmosphere. Built for discerning collectors and trendsetters across Riyadh, Dubai, and Doha, the UI balances cultural grandeur with futuristic digital brutalism.

The design movement bridges **Avant-Garde Architectural Brutalism** with **Minimalist High-Contrast Luxury**. The aesthetic relies on an absolute dark obsidian canvas (`#05080A`), punctuated by razor-sharp emerald pulses (`#10B981`) and subtle deep gold/bronze metallic micro-accents. Elements do not float passively; they are framed within strict, zero-radius monolithic blocks and hyper-refined hairline borders. The emotional impact is precise, authoritative, and deeply exclusive.

## Colors
The palette operates strictly within high-contrast nocturnal values:

- **Primary (`#10B981`):** Electric Emerald. Used sparingly for critical forward-driving interactions, active selection indicators, and prestige highlights. It flashes against the deep dark canvas with vibrant energy.
- **Secondary (`#0F172A`):** Deep Obsidian Navy. Acts as structural container layering, monolithic paneling, and architectural framing behind products.
- **Tertiary (`#D97706`):** Warm Gilded Bronze. Reserved strictly for curated editorial tags, VIP membership tiers, and subtle metal accents.
- **Neutral (`#090D14`):** Void Black base foundation. Serves as the canvas floor (`#05080A`), surface elevated levels (`#0F172A`), and border strokes (`#1E293B`).
- **Foreground / Text:** Pure stark white (`#FFFFFF`) for primary headings and prices; muted slate (`#94A3B8`) for editorial descriptions and metadata; dark slate (`#475569`) for subtle guides.
- **Status / Alert:** Crimson scarlet (`#EF4444`) strictly reserved for system errors and exclusive flash inventory limits.

## Typography
Typographic scale unites **Syne**'s expressive, sculptural geometry with **Space Grotesk**'s utilitarian precision.

- **Syne** commands all visual anchors: display banners, collection chapter titles, and hero luxury statements. It introduces deliberate visual friction and an haute-couture silhouette.
- **Space Grotesk** drives all transactional and functional reading: Arabic/Latin dual-script catalog data, product specifications, micro-labels, and SKU IDs.
- For Arabic localized script, characters inherit proportional vertical line metrics matching Syne's dynamic structural baseline, ensuring harmonious multi-lingual and RTL visual parity. All numerical prices utilize monospaced styling within `Space Grotesk` to honor currency and luxury valuation alignment.

## Layout & Spacing
The layout follows a strict monolithic grid inspired by museum gallery installations:

- **Grid Framework:** A 12-column dynamic grid on desktop (`1280px+`), collapsing to 6 columns on tablet (`768px-1023px`), and 2 asymmetrical columns on mobile (`360px-767px`).
- **RTL & Flow Mechanics:** Canvas flows seamlessly right-to-left. Margins, navigation vectors, and column sequences invert naturally while maintaining vertical architectural lines.
- **Negative Space Rhythm:** Generous horizontal breathing room contrasts dense, structural typographic clusters. High-impact lookbook sections span full bleed, snapped between rigid structural lines.

## Elevation & Depth
Depth in this system avoids diffused drop-shadows or pillowy soft elevations. Instead, visual hierarchy is constructed through **Architectural Tonal Stratification** and **Luminescent Hairline Framing**:

1. **Floor Level (Canvas):** `#05080A` base background.
2. **Structural Tier 1 (Cards, Modules):** `#0A0F17` surfaces separated not by drop shadows, but by crisp `1px solid #1E293B` boundaries.
3. **Floating Tier 2 (Drawers, Modals, Sticky Nav):** `#0F172A` with backdrop-filter blur (`16px`) and an intense top/border hairline accent in `#10B981` (20% opacity).
4. **Active State Elevation:** Interactive components rise optically through border luminescence: applying a hard `1px` outline of `#10B981` and an optional ambient directional glow: `box-shadow: 0 0 24px -4px rgba(16, 185, 129, 0.18)`.

## Shapes
The shape system commits decisively to **0px roundedness (Sharp Architecture)**. 

Every visual module—including buttons, product frames, modals, badges, inputs, and image viewports—features razor-sharp 90-degree corners. This evokes the feeling of cut raw emeralds, polished black marble, and high-fashion architectural spaces. Curves and circular radiuses are entirely forbidden, enforcing discipline and avant-garde luxury across all touchpoints.

## Components

### Buttons & Interactive Controls
- **Primary CTA:** Monolithic rectangular block, solid `#10B981` fill with `#05080A` bold `Space Grotesk` uppercase text. Zero border radius. Hover state triggers a reverse inversion: `#05080A` background with `#10B981` sharp border and text.
- **Secondary CTA:** Obsidian `#0F172A` surface with a crisp `1px solid #334155` border and white typography.
- **Editorial Ghost Button:** Transparent background, `1px solid #10B981` outline, pure emerald typography with sharp arrow cues aligned for RTL (`←` in RTL, `→` in LTR).

### Product Cards
- **Structure:** Angular vertical monoliths. Zero radius.
- **Imagery:** Edge-to-edge imagery with deep slate underlays (`#0A0F17`). On hover/touch, images scale subtly by 2% within their rigid bounds without softening edges.
- **Metadata Pane:** Positioned flush beneath the image frame, featuring category cues in `label-caps`, garment names in `headline-sm`, and pricing in electric emerald numeric styling.

### Input Fields & Search
- **Container:** Boxy rectangular frames, background `#0A0F17`, framed with `1px solid #1E293B`.
- **Focus State:** Hairline border switches instantaneously to `#10B981` accompanied by a localized corner micro-pip accent. Text is crisp `#FFFFFF` with muted slate placeholder values.

### Chips & Filter Selectors
- **Default:** Sharp rectangular tags in `#0F172A` with `#334155` borders.
- **Selected:** Solid `#10B981` background or deep black with sharp emerald border markers and contrasting white text.

### Navigation Dock (Thumb-Zone Luxury Nav)
- **Bar Form:** Floating anchored bar at screen bottom, spanning screen width minus margins, framed with zero border radius, backed by frosted obsidian acrylic (`#090D14` at 92% opacity with heavy blur).
- **Active Markers:** Active tab icons/labels are underlined with a razor-thin 2px `#10B981` geometric line.